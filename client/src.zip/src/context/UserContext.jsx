import { createContext, useContext, useState } from "react";
import { CacheContext } from "./CacheContext";

export const UserContext = createContext(null);

const USER_KEY = "currentUser";

// המשתמש המחובר. נשמר ב-Local Storage, כדי שיישאר מחובר גם אחרי ריענון
function UserProvider({ children }) {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem(USER_KEY)));
  const { setCache } = useContext(CacheContext);

  function login(userData) {
    localStorage.setItem(USER_KEY, JSON.stringify(userData));
    setUser(userData);
  }

  // יציאה: מוחקים את המשתמש מה-LS, ואת המידע שלו מה-Cache
  function logout() {
    localStorage.removeItem(USER_KEY);
    setCache({});
    setUser(null);
  }

  return (
    <UserContext.Provider value={{ user, login, logout }}>
      {children}
    </UserContext.Provider>
  );
}

export default UserProvider;
